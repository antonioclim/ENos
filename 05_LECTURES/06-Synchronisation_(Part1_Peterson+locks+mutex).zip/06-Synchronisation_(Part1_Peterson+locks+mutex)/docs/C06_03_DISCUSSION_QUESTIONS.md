# Discussion Questions — Synchronisation P1

1. **Why does Peterson not work on modern multi-core without memory barriers?**
2. **When do you prefer spinlock vs mutex?**
3. **What problems does lock granularity bring (coarse vs fine)?**
4. **Priority inversion**: What is it and how is it resolved?
