# Lecture Plan — Synchronisation Part 1
> Week 6 | by Revolvix

## Objectives
1. Identify race conditions and critical sections
2. Explain software solutions (Peterson) and hardware solutions (TAS, CAS)
3. Implement and use mutexes and spinlocks
4. Analyse trade-offs between synchronisation mechanisms
