# Course Plan — Virtual Memory
> Week 10 | by Revolvix

## Objectives
1. Explain the concept of virtual memory and demand paging
2. Analyse the role of TLB and its impact on performance
3. Compare page replacement algorithms (FIFO, LRU, OPT)
4. Identify and prevent thrashing
