# Discussion Questions — Virtual Memory

1. **Why is TLB crucial for performance?**
2. **LRU vs Clock**: Trade-offs?
3. **How do you prevent thrashing?**
4. **Working Set**: How do you determine it in practice?
