# Course Plan — Deadlock
> Week 8 | by Revolvix

## Objectives
1. Define deadlock and the Coffman conditions
2. Use Resource Allocation Graph for detection
3. Apply prevention and avoidance algorithms (Banker)
4. Evaluate recovery strategies
