# Discussion Questions — Deadlock

1. **How do you prevent circular wait in practice?**
2. **Why is Banker's Algorithm not frequently used?**
3. **Livelock vs Deadlock**: What is the difference?
4. **Trade-offs**: Prevention vs Detection+Recovery?
