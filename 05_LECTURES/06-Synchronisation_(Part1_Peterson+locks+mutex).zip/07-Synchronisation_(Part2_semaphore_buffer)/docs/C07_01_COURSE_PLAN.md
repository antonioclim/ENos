# Course Plan — Synchronisation Part 2
> Week 7 | by Revolvix

## Objectives
1. Explain semaphores (counting and binary)
2. Solve classic problems: producer-consumer, readers-writers
3. Use monitors and condition variables
4. Avoid deadlock in synchronisation
