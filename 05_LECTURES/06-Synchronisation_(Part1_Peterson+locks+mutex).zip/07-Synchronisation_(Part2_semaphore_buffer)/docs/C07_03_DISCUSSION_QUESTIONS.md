# Discussion Questions — Synchronisation P2

1. **Why is the wait() order critical for avoiding deadlock?**
2. **Readers-Writers**: How do you prevent starvation for writers?
3. **Dining Philosophers**: What are the solutions?
4. **Monitors vs Semaphores**: Advantages/disadvantages?
