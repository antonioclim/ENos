# Course Plan — Memory Management Part 1
> Week 9 | by Revolvix

## Objectives
1. Explain the concepts of logical vs physical address
2. Describe the mechanisms of paging and segmentation
3. Analyse the page table structure and the role of MMU
4. Compare internal vs external fragmentation
