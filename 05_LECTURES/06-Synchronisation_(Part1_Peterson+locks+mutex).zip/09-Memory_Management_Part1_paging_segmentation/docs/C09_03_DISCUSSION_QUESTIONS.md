# Discussion Questions — Memory Management P1

1. **Why is the page size a power of 2?**
2. **Trade-offs for large vs small page size?**
3. **Why do multi-level page tables save memory?**
4. **Segmentation**: When is it more suitable than paging?
