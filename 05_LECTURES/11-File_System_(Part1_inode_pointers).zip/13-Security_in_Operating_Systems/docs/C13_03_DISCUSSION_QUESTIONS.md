# Discussion Questions — OS Security

1. **Why are SUID root programs dangerous?**
2. **ASLR**: Which attacks does it prevent and which bypass it?
3. **Containers vs VMs**: Which provides better isolation?
4. **Sandboxing**: How does seccomp work?
