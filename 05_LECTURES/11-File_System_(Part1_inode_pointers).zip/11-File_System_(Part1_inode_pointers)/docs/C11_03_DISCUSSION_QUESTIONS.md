# Discussion Questions — File System P1

1. **Why does the inode not contain the file name?**
2. **Hard vs Soft link**: When do you use each?
3. **What happens when you delete a file with hard links?**
4. **Why do we need indirect pointers?**
