# Course Plan — File System Part 1
> Week 11 | by Revolvix

## Objectives
1. Explain the structure and role of inodes
2. Describe the pointer system (direct, indirect)
3. Differentiate hard links from symbolic links
4. Navigate the directory hierarchy
