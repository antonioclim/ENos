# Discussion Questions — Virtualisation

1. **Type 1 vs Type 2**: When do you use each?
2. **Why is paravirtualisation faster?**
3. **VM escape vs container escape**: Differences in impact?
4. **Live migration**: How does it work and when is it useful?
