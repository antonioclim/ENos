# Course Plan — Virtualisation + Recap
> Week 14 | by Revolvix

## Objectives
1. Explain the concepts of virtualisation and hypervisor
2. Compare Type 1 vs Type 2 hypervisors
3. Describe the mechanisms: shadow PT, EPT, paravirtualisation
4. Differentiate VMs from containers
