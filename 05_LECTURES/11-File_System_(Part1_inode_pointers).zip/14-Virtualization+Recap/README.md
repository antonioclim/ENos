# Operating Systems - Week 14: Virtualisation and Recap

> **by Revolvix** | ASE Bucharest - CSIE | Year I, Semester 2 | 2025-2026

---

## Week Objectives

After completing the materials from this week, you will be able to:

1. **Differentiate** between full virtualisation, paravirtualisation and containerisation
2. Explain the role of the hypervisor and its types (Type-1 vs Type-2)
3. Describe the Linux mechanisms that enable containers: namespaces and cgroups
4. **Use** basic Docker commands for container management
5. **Synthesise** OS concepts into a complete concept map
6. **Evaluate** the relationships between concepts studied throughout the semester

---

## Applied Context (didactic scenario): Why is Kubernetes the "Operating System of the Cloud"?

In the cloud, you do not run applications directly on physical servers. You have a complex stack: physical hardware → hypervisor → virtual machines → container runtime → containers → applications. Each layer adds abstraction and isolation.

Kubernetes orchestrates thousands of containers across hundreds of nodes, just as Linux orchestrates thousands of processes on a single computer. It does for containers what an OS does for processes:
- **Scheduling**: Decides on which node each container runs
- **Resource management**: Allocates CPU, memory, storage
- **Health monitoring**: Restarts failed containers
- **Networking**: Allows containers to communicate

> 💡 **Think about it**: What OS concepts have we studied that are found in Kubernetes? (Hint: scheduling, namespaces, cgroups, signals...)

---

## Course Content (14/14)

### 1. Virtualisation: Fundamental Concepts

#### Formal Definition

> **Virtualisation** is the technique of creating virtual versions of hardware resources (CPU, memory, storage, network), allowing multiple isolated operating systems to run on the same physical hardware. The software layer that manages this is called the **hypervisor** or **Virtual Machine Monitor (VMM)**.

#### Why Virtualisation?

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      MOTIVATIONS FOR VIRTUALISATION                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1. SERVER CONSOLIDATION                                                     │
│  ──────────────────────────                                                  │
│  Before:                          After:                                     │
│  [Server 1: 5% CPU] ─┐             ┌────────────────────────┐               │
│  [Server 2: 10% CPU] ├──→          │ 1 Physical server:     │               │
│  [Server 3: 3% CPU]  │             │  VM1 + VM2 + VM3       │               │
│  [Server 4: 8% CPU] ─┘             │  Utilisation: 70% CPU  │               │
│                                     └────────────────────────┘               │
│  4 servers at 7% average → 1 server at 70%                                  │
│  Savings: energy, space, cooling, management                                │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  2. ISOLATION AND SECURITY                                                   │
│  ────────────────────────────                                                │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │                           HOST                                        │   │
│  │  ┌────────────┐  ┌────────────┐  ┌────────────┐                      │   │
│  │  │ VM Prod    │  │ VM Test    │  │ VM Dev     │                      │   │
│  │  │ (isolated) │  │ (isolated) │  │ (isolated) │                      │   │
│  │  └────────────┘  └────────────┘  └────────────┘                      │   │
│  │                                                                       │   │
│  │  A bug in VM Test does NOT affect VM Prod!                           │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  3. PORTABILITY AND DISASTER RECOVERY                                        │
│  ────────────────────────────────────────                                    │
│  - VM = file(s) on disk                                                     │
│  - Copy the file → you have a complete system backup                        │
│  - Live migration: move VM from one host to another without downtime        │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  4. DEVELOPMENT AND TESTING                                                  │
│  ─────────────────────────────                                               │
│  - Test on Windows, Linux, FreeBSD - all on the same laptop                 │
│  - Snapshots: save state, experiment, revert                                │
│  - Reproducible environments for CI/CD                                      │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### 2. Types of Virtualisation

#### Classification by Hypervisor

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    HYPERVISOR TYPES                                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  TYPE 1 (Bare-Metal)                   TYPE 2 (Hosted)                       │
│  ════════════════════                  ════════════════                      │
│                                                                              │
│  ┌─────────────────────────┐          ┌─────────────────────────┐           │
│  │  VM1    VM2    VM3      │          │  VM1    VM2    VM3      │           │
│  ├─────────────────────────┤          ├─────────────────────────┤           │
│  │      HYPERVISOR         │          │      HYPERVISOR         │           │
│  │  (directly on hardware) │          │   (as application)      │           │
│  ├─────────────────────────┤          ├─────────────────────────┤           │
│  │       HARDWARE          │          │      HOST OS            │           │
│  └─────────────────────────┘          │  (Windows, Linux, Mac)  │           │
│                                        ├─────────────────────────┤           │
│                                        │       HARDWARE          │           │
│                                        └─────────────────────────┘           │
│                                                                              │
│  Examples:                             Examples:                             │
│  - VMware ESXi                         - VirtualBox                          │
│  - Microsoft Hyper-V                   - VMware Workstation                  │
│  - Xen                                 - Parallels Desktop                   │
│  - KVM (with QEMU)                     - VMware Fusion                       │
│                                                                              │
│  ┌──────────────────────────────────────────────────────────────────────┐   │
│  │ Performance: Type 1 >> Type 2                                         │   │
│  │ Complexity: Type 1 > Type 2                                           │   │
│  │ Use case Type 1: Datacenters, production                              │   │
│  │ Use case Type 2: Development, testing, desktop                        │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Full Virtualisation vs Paravirtualisation

```
┌─────────────────────────────────────────────────────────────────────────────┐
│              FULL VIRTUALISATION vs PARAVIRTUALISATION                       │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  FULL VIRTUALISATION                                                         │
│  ═══════════════════                                                         │
│                                                                              │
│  Guest OS believes it runs on real hardware.                                │
│  The hypervisor emulates/intercepts privileged instructions.                │
│                                                                              │
│  Guest OS        Hypervisor        Hardware                                  │
│      │               │                │                                      │
│      │──HLT (priv)──→│                │                                      │
│      │               │──trap──────────│                                      │
│      │               │←──────────────→│                                      │
│      │←──emulated────│                │                                      │
│                                                                              │
│  ✅ Pro: Unmodified Guest OS (Windows, anything)                            │
│  ❌ Con: Overhead from trap & emulate                                       │
│  📍 Accelerated by: Intel VT-x, AMD-V (hardware virtualisation)             │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  PARAVIRTUALISATION                                                          │
│  ════════════════════                                                        │
│                                                                              │
│  Guest OS knows it is virtualised and uses direct "hypercalls".             │
│                                                                              │
│  Guest OS        Hypervisor        Hardware                                  │
│      │               │                │                                      │
│      │──hypercall───→│                │                                      │
│      │               │────────────────│                                      │
│      │←──response───│                │                                      │
│                                                                              │
│  ✅ Pro: Faster (no trap overhead)                                          │
│  ❌ Con: Requires Guest OS modification (special drivers)                   │
│  📍 Example: Xen paravirt, VirtIO drivers                                   │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  IN PRACTICE: Hybrid                                                         │
│  - CPU: Full virtualisation (VT-x) → zero overhead                          │
│  - I/O: Paravirtualisation (VirtIO) → better disk/network performance       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### 3. Containerisation: OS-Level Virtualisation

#### Formal Definition

> **Containerisation** is a form of operating system-level virtualisation, where the kernel allows the existence of multiple isolated user space instances (containers). Unlike VMs, containers **share the kernel** of the host.

#### VM vs Container: Visual Comparison

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                      VIRTUALISATION vs CONTAINERISATION                      │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  VIRTUAL MACHINES                      CONTAINERS                            │
│                                                                              │
│  ┌──────┐ ┌──────┐ ┌──────┐           ┌──────┐ ┌──────┐ ┌──────┐           │
│  │ App1 │ │ App2 │ │ App3 │           │ App1 │ │ App2 │ │ App3 │           │
│  ├──────┤ ├──────┤ ├──────┤           ├──────┤ ├──────┤ ├──────┤           │
│  │ Bins │ │ Bins │ │ Bins │           │ Bins │ │ Bins │ │ Bins │           │
│  │ Libs │ │ Libs │ │ Libs │           │ Libs │ │ Libs │ │ Libs │           │
│  ├──────┤ ├──────┤ ├──────┤           └──┬───┘ └──┬───┘ └──┬───┘           │
│  │Guest │ │Guest │ │Guest │              │        │        │                │
│  │  OS  │ │  OS  │ │  OS  │              └────────┼────────┘                │
│  │      │ │      │ │      │                       │                         │
│  └──┬───┘ └──┬───┘ └──┬───┘           ┌──────────┴──────────┐              │
│     └────────┼────────┘               │  Container Runtime   │              │
│              │                        │  (Docker Engine)     │              │
│  ┌───────────┴───────────┐            └──────────┬──────────┘              │
│  │      HYPERVISOR       │                       │                         │
│  └───────────┬───────────┘            ┌──────────┴──────────┐              │
│              │                        │      HOST OS         │              │
│  ┌───────────┴───────────┐            │  (Linux Kernel)      │              │
│  │       HOST OS         │            └──────────┬──────────┘              │
│  └───────────┬───────────┘                       │                         │
│              │                        ┌──────────┴──────────┐              │
│  ┌───────────┴───────────┐            │     HARDWARE        │              │
│  │      HARDWARE         │            └─────────────────────┘              │
│  └───────────────────────┘                                                  │
│                                                                              │
│  Overhead: HIGH                        Overhead: LOW                         │
│  Isolation: COMPLETE                   Isolation: PROCESS                    │
│  Boot: MINUTES                         Boot: SECONDS                         │
│  Size: GB                              Size: MB                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Detailed Comparison Table

| Aspect | Virtual Machine | Container |
|--------|-----------------|-----------|
| **Isolation** | Complete (virtual hardware) | Process (shared kernel) |
| **Boot time** | 30s - 5 min | < 1 second |
| **Size** | GB (includes OS) | MB (application only) |
| **CPU overhead** | 5-15% | ~1% |
| **Memory overhead** | Hundreds of MB per VM | Minimal |
| **Density** | Tens per host | Hundreds/thousands per host |
| **Portability** | Limited | Excellent |
| **Security** | Stronger (separate kernel) | Weaker (shared kernel) |
| **Use case** | Multi-tenant, legacy apps | Microservices, CI/CD |

---

### 4. Linux Namespaces: Container Isolation

#### Formal Definition

> **Namespaces** are a Linux kernel feature that isolates system resources for groups of processes. Each namespace provides processes with their "own" view of a global resource.

#### Namespace Types

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         LINUX NAMESPACES                                     │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ Namespace │ Isolates                       │ Example                │    │
│  ├───────────┼────────────────────────────────┼────────────────────────┤    │
│  │ PID       │ Process IDs                    │ Container sees PID 1  │    │
│  │           │                                │ (its own init)        │    │
│  ├───────────┼────────────────────────────────┼────────────────────────┤    │
│  │ NET       │ Network interfaces, IPs        │ Container has its own │    │
│  │           │                                │ eth0                  │    │
│  ├───────────┼────────────────────────────────┼────────────────────────┤    │
│  │ MNT       │ Mount points                   │ Container sees only   │    │
│  │           │                                │ its own filesystem    │    │
│  ├───────────┼────────────────────────────────┼────────────────────────┤    │
│  │ UTS       │ Hostname, domain name          │ Container has its own │    │
│  │           │                                │ hostname              │    │
│  ├───────────┼────────────────────────────────┼────────────────────────┤    │
│  │ IPC       │ IPC resources (semaphores,SHM) │ Container has isolated│    │
│  │           │                                │ IPC                   │    │
│  ├───────────┼────────────────────────────────┼────────────────────────┤    │
│  │ USER      │ UID/GID mappings               │ root in container =   │    │
│  │           │                                │ normal user on host   │    │
│  ├───────────┼────────────────────────────────┼────────────────────────┤    │
│  │ CGROUP    │ Cgroup root directory          │ Resource limits       │    │
│  │           │                                │ isolation             │    │
│  └───────────┴────────────────────────────────┴────────────────────────┘    │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  VISUALISATION:                                                              │
│                                                                              │
│           HOST (global view)                                                 │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │  PIDs: 1, 2, 3, ... 1000, 1001, 1002, ... 5000                      │    │
│  │  Hostname: server01                                                  │    │
│  │  Network: eth0 (192.168.1.100)                                      │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                  │                         │                                 │
│                  ▼                         ▼                                 │
│  ┌─────────────────────────┐  ┌─────────────────────────┐                   │
│  │    Container A          │  │    Container B          │                   │
│  │  PIDs: 1, 2, 3          │  │  PIDs: 1, 2, 3, 4       │                   │
│  │  Hostname: webapp       │  │  Hostname: database     │                   │
│  │  Network: eth0 (10.0.0.2│  │  Network: eth0 (10.0.0.3│                   │
│  │  Sees ONLY its own /    │  │  Sees ONLY its own /    │                   │
│  └─────────────────────────┘  └─────────────────────────┘                   │
│                                                                              │
│  Container A believes it is alone on the machine!                           │
│  Container B believes it is alone on the machine!                           │
│  The host sees ALL processes (PID 1000-1003, 5000-5004)                    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Practical Verification: Namespaces

```bash
# View namespaces of the current process
ls -la /proc/$$/ns/

# Output:
# lrwxrwxrwx 1 user user 0 Jan 15 10:30 cgroup -> 'cgroup:[4026531835]'
# lrwxrwxrwx 1 user user 0 Jan 15 10:30 ipc -> 'ipc:[4026531839]'
# lrwxrwxrwx 1 user user 0 Jan 15 10:30 mnt -> 'mnt:[4026531840]'
# lrwxrwxrwx 1 user user 0 Jan 15 10:30 net -> 'net:[4026531992]'
# lrwxrwxrwx 1 user user 0 Jan 15 10:30 pid -> 'pid:[4026531836]'
# lrwxrwxrwx 1 user user 0 Jan 15 10:30 user -> 'user:[4026531837]'
# lrwxrwxrwx 1 user user 0 Jan 15 10:30 uts -> 'uts:[4026531838]'

# Create namespace manually (requires privileges)
sudo unshare --pid --fork --mount-proc bash
# Now you are in a new PID namespace!
ps aux  # You will see only processes from this namespace
exit

# Comparison with Docker container
docker run --rm -it ubuntu ps aux
# The container sees only its own processes
```

---

### 5. Control Groups (cgroups): Resource Limiting

#### Formal Definition

> **Control Groups (cgroups)** are a Linux kernel feature that allows limiting, accounting and isolating resource usage (CPU, memory, disk I/O, network) for groups of processes.

#### What You Can Limit with cgroups

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                          CGROUPS CONTROLLERS                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │ Controller │ What it limits         │ Example                       │    │
│  ├────────────┼────────────────────────┼───────────────────────────────┤    │
│  │ cpu        │ CPU time               │ Max 50% of one core           │    │
│  │ cpuset     │ Which CPU cores        │ Only cores 0-3                │    │
│  │ memory     │ RAM memory             │ Max 512 MB                    │    │
│  │ blkio      │ Disk I/O               │ Max 10 MB/s write             │    │
│  │ net_cls    │ Traffic classification │ Priority in QoS               │    │
│  │ devices    │ Access to devices      │ Block /dev/sda                │    │
│  │ freezer    │ Process suspension     │ Pause/resume container        │    │
│  │ pids       │ Number of processes    │ Max 100 processes             │    │
│  └────────────┴────────────────────────┴───────────────────────────────┘    │
│                                                                              │
│  ════════════════════════════════════════════════════════════════════════   │
│                                                                              │
│  EXAMPLE: Container with limits                                              │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      CGROUP: container_webapp                        │    │
│  │                                                                      │    │
│  │  cpu.max: 100000 100000  (100% of 1 core)                           │    │
│  │  memory.max: 536870912   (512 MB)                                   │    │
│  │  memory.swap.max: 0      (no swap)                                  │    │
│  │  pids.max: 50            (max 50 processes)                         │    │
│  │                                                                      │    │
│  │  Member processes:                                                   │    │
│  │  ├── PID 1000 (nginx master)                                        │    │
│  │  ├── PID 1001 (nginx worker)                                        │    │
│  │  ├── PID 1002 (nginx worker)                                        │    │
│  │  └── PID 1003 (nginx worker)                                        │    │
│  │                                                                      │    │
│  │  If nginx tries to use >512 MB → OOM kill                           │    │
│  │  If it tries to create >50 processes → "no resources" error         │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Practical Verification: cgroups

```bash
# Cgroups v2 (modern systems)
cat /sys/fs/cgroup/cgroup.controllers
# cpu io memory pids

# View limits for a Docker container
docker run -d --name test --memory=256m --cpus=0.5 nginx
cat /sys/fs/cgroup/system.slice/docker-$(docker inspect --format '{{.Id}}' test)/memory.max
# 268435456 (256 MB in bytes)

docker rm -f test
```

---

### 6. Docker: Containerisation in Practice

#### Docker Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                         DOCKER ARCHITECTURE                                  │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        DOCKER CLIENT                                 │    │
│  │                   (docker CLI, docker-compose)                       │    │
│  └────────────────────────────┬────────────────────────────────────────┘    │
│                               │ REST API                                     │
│                               ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                        DOCKER DAEMON                                 │    │
│  │                         (dockerd)                                    │    │
│  │  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐                  │    │
│  │  │   Images    │  │  Containers │  │  Networks   │                  │    │
│  │  │  Management │  │  Management │  │  Management │                  │    │
│  │  └─────────────┘  └─────────────┘  └─────────────┘                  │    │
│  └────────────────────────────┬────────────────────────────────────────┘    │
│                               │                                              │
│                               ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                      CONTAINERD                                      │    │
│  │              (high-level container runtime)                          │    │
│  └────────────────────────────┬────────────────────────────────────────┘    │
│                               │                                              │
│                               ▼                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐    │
│  │                          RUNC                                        │    │
│  │         (low-level container runtime - OCI compliant)                │    │
│  │                                                                      │    │
│  │    Creates container using:                                          │    │
│  │    ├── namespaces (isolation)                                       │    │
│  │    ├── cgroups (resource limits)                                    │    │
│  │    ├── seccomp (syscall filtering)                                  │    │
│  │    └── capabilities (granular permissions)                          │    │
│  └─────────────────────────────────────────────────────────────────────┘    │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

#### Essential Docker Commands

```bash
# ═══════════════════════════════════════════════════════════════════════════
# IMAGES (read-only templates for containers)
# ═══════════════════════════════════════════════════════════════════════════

# List local images
docker images

# Download image
docker pull ubuntu:24.04

# Search images on Docker Hub
docker search nginx

# Build image from Dockerfile
docker build -t myapp:1.0 .

# ═══════════════════════════════════════════════════════════════════════════
# CONTAINERS (instances of images)
# ═══════════════════════════════════════════════════════════════════════════

# Run simple container
docker run hello-world

# Run interactively with terminal
docker run -it ubuntu:24.04 bash

# Run in background (detached)
docker run -d --name webserver -p 8080:80 nginx

# List active containers
docker ps

# List all containers (including stopped)
docker ps -a

# Stop container
docker stop webserver

# Start stopped container
docker start webserver

# Delete container
docker rm webserver

# View logs
docker logs webserver
docker logs -f webserver  # follow (like tail -f)

# Execute command in running container
docker exec -it webserver bash

# ═══════════════════════════════════════════════════════════════════════════
# RESOURCES AND LIMITS
# ═══════════════════════════════════════════════════════════════════════════

# Limit memory and CPU
docker run -d --name limited \
    --memory=256m \
    --cpus=0.5 \
    nginx

# View real-time statistics
docker stats

# Inspect container (all details)
docker inspect webserver

# ═══════════════════════════════════════════════════════════════════════════
# NETWORKING
# ═══════════════════════════════════════════════════════════════════════════

# List networks
docker network ls

# Create network
docker network create mynetwork

# Connect container to network
docker run -d --name db --network mynetwork postgres

# ═══════════════════════════════════════════════════════════════════════════
# VOLUMES (data persistence)
# ═══════════════════════════════════════════════════════════════════════════

# Create volume
docker volume create mydata

# Mount volume
docker run -d --name db -v mydata:/var/lib/postgresql/data postgres

# Mount local directory
docker run -d -v /host/path:/container/path nginx
```

---

### 7. Concept Map: Everything We Have Learned

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    OPERATING SYSTEMS - CONCEPT MAP                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│                              ┌─────────────┐                                 │
│                              │     OS      │                                 │
│                              │ (Kernel)    │                                 │
│                              └──────┬──────┘                                 │
│                                     │                                        │
│         ┌───────────────┬───────────┼───────────┬───────────────┐           │
│         │               │           │           │               │           │
│         ▼               ▼           ▼           ▼               ▼           │
│  ┌─────────────┐ ┌─────────────┐ ┌─────────┐ ┌─────────────┐ ┌──────────┐  │
│  │  PROCESSES  │ │   MEMORY    │ │  FILES  │ │     I/O     │ │ SECURITY │  │
│  └──────┬──────┘ └──────┬──────┘ └────┬────┘ └──────┬──────┘ └────┬─────┘  │
│         │               │             │             │              │        │
│  ┌──────┴──────┐ ┌──────┴──────┐ ┌────┴────┐ ┌──────┴──────┐ ┌────┴────┐   │
│  │Process state│ │Virtual mem  │ │ Inodes  │ │   Drivers   │ │   AAA   │   │
│  │PCB, context │ │Paging       │ │Directories│ │ Buffering │ │Permissions│ │
│  │fork, exec   │ │TLB, cache   │ │  Links  │ │   Polling  │ │ACL, RBAC│   │
│  └──────┬──────┘ └──────┬──────┘ └────┬────┘ └─────────────┘ └─────────┘   │
│         │               │             │                                     │
│  ┌──────┴──────┐ ┌──────┴──────┐ ┌────┴────┐                               │
│  │ SCHEDULING  │ │Page Replace │ │Journaling│                               │
│  ├─────────────┤ ├─────────────┤ │  VFS    │                               │
│  │FCFS, SJF    │ │FIFO, LRU    │ │ ext4    │                               │
│  │RR, Priority │ │OPT, Clock   │ │         │                               │
│  │MLFQ, CFS    │ │Working Set  │ │         │                               │
│  └──────┬──────┘ └─────────────┘ └─────────┘                               │
│         │                                                                   │
│  ┌──────┴──────────────────────────────┐                                   │
│  │         SYNCHRONISATION             │                                   │
│  │  ├── Race conditions                │                                   │
│  │  ├── Critical section               │                                   │
│  │  ├── Mutex, Semaphores             │                                   │
│  │  ├── Deadlock (Coffman)            │                                   │
│  │  └── Producer-Consumer             │                                   │
│  └─────────────────────────────────────┘                                   │
│                                                                              │
│  ═══════════════════════════════════════════════════════════════════════   │
│                                                                              │
│                         VIRTUALISATION & CONTAINERS                          │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │  VM: Hypervisor (Type 1/2) → Complete Guest OS                      │   │
│  │  Container: Namespaces + Cgroups → Isolated process                 │   │
│  │  Docker: Image → Container → Network → Volume                       │   │
│  │  Kubernetes: Pod → Deployment → Service → Ingress                   │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

### 8. Connections Between Concepts

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    RELATIONSHIPS BETWEEN OS CONCEPTS                         │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  PROCESSES ←──────────────────────────────────────────────────→ MEMORY      │
│    │         fork() allocates memory (CoW)                          │       │
│    │         Each process has virtual address space                 │       │
│    │         Page faults interrupt process execution                │       │
│    │                                                                │       │
│    │                                                                │       │
│  SCHEDULING ←──────────────────────────────────────────────→ SYNCHRONISATION│
│    │         Scheduler decides who runs when                        │       │
│    │         Synchronisation requires context switch                │       │
│    │         Mutexes can cause priority inversion                   │       │
│    │                                                                │       │
│    │                                                                │       │
│  PROCESSES ←──────────────────────────────────────────────────→ FILES       │
│    │         open() creates file descriptor                         │       │
│    │         fork() duplicates file descriptors                     │       │
│    │         PCB contains the file descriptor table                 │       │
│    │                                                                │       │
│    │                                                                │       │
│  FILES ←──────────────────────────────────────────────────→ MEMORY          │
│    │         mmap() maps files into memory                          │       │
│    │         Page cache accelerates reading                         │       │
│    │         Dirty pages must be written to disk                    │       │
│    │                                                                │       │
│    │                                                                │       │
│  SECURITY ←────────────────────────────────────────────→ PROCESSES          │
│    │         Permissions checked at open()                          │       │
│    │         UID/GID stored in PCB                                  │       │
│    │         Capabilities limit what root can do                    │       │
│    │                                                                │       │
│    │                                                                │       │
│  VIRTUALISATION ←───────────────────────────────────────────→ ALL           │
│              Hypervisor virtualises hardware (CPU, mem, I/O)               │
│              Namespaces isolate process view                               │
│              Cgroups limit resources (CPU, memory)                         │
│              Containers combine all OS concepts!                           │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Laboratory/Seminar (Session 7/7) - PRESENTATIONS

### Programme

| Time | Activity |
|------|----------|
| 0:00-0:10 | Introduction, establishing presentation order |
| 0:10-1:30 | Project presentations (7-10 min/team + Q&A) |
| 1:30-1:50 | General feedback, discussions |
| 1:50-2:00 | Recap for exam, final questions |

### Assignment 7: Reflection Document

Document of 0.5-1 page with:

1. **Top 3 concepts** the most important from the course and why
2. **A surprising concept** that you would not have anticipated
3. **Practical applicability** - how you will use this knowledge
4. **Self-assessment** - what you understood well, what needs more study

---

## Exam Preparation

### Study Strategies

1. **Re-read** weekly notes with focus on concepts, not memorisation
2. **Solve** OSTEP exercises at the end of each chapter
3. **Practise** calculations: scheduling (Gantt charts), paging (addresses), page replacement
4. **Draw** diagrams: process states, paging, deadlock
5. **Explain** each concept to someone else (Feynman technique)

### Probable Question Types

- **Calculation**: Waiting time, turnaround time, page faults
- **Comparison**: VM vs Container, DAC vs MAC, Hard vs Soft link
- **Diagrams**: Complete process states, draw Gantt chart
- **Scenarios**: "What happens if..."
- **Concepts**: Definitions, mechanisms, trade-offs

### Key Concepts per Topic

```
□ Week 1-2: OS role, syscalls, user/kernel space
□ Week 3-4: Processes, states, fork/exec, scheduling (FCFS, SJF, RR, MLFQ)
□ Week 5-6: Threads, race conditions, critical section, mutex, semaphore
□ Week 7-8: Deadlock (Coffman), Banker's algorithm, producer-consumer
□ Week 9-10: Virtual memory, paging, TLB, page replacement (FIFO, LRU, OPT)
□ Week 11-12: Filesystem, inodes, links, journaling, extents
□ Week 13: Security, permissions, ACL, DAC/MAC/RBAC
□ Week 14: Virtualisation, containers, namespaces, cgroups, Docker
```

---

## Recommended Reading

### OSTEP (Operating Systems: Three Easy Pieces)
- [Appendix B - Virtual Machine Monitors](https://pages.cs.wisc.edu/~remzi/OSTEP/vmm-intro.pdf)

### Tanenbaum - Modern Operating Systems
- Chapter 7: Virtualization and the Cloud

### Official Documentation
- [Docker Documentation](https://docs.docker.com/)
- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [Linux Namespaces man page](https://man7.org/linux/man-pages/man7/namespaces.7.html)

---

## New Commands Summary

| Command | Description | Example |
|---------|-------------|---------|
| `docker run` | Run container | `docker run -it ubuntu bash` |
| `docker ps` | List containers | `docker ps -a` |
| `docker images` | List images | `docker images` |
| `docker build` | Build image | `docker build -t app:1.0 .` |
| `docker exec` | Execute in container | `docker exec -it web bash` |
| `docker logs` | View logs | `docker logs -f web` |
| `docker stats` | Live statistics | `docker stats` |
| `unshare` | Create namespace | `sudo unshare --pid bash` |
| `nsenter` | Enter namespace | `nsenter -t PID -n bash` |

---


---


---

## Nuances and Special Cases

### What We Did NOT Cover (didactic limitations)

- **Nested virtualisation**: VM inside VM (useful for cloud testing).
- **GPU virtualisation**: SR-IOV, vGPU for sharing GPU between VMs.
- **Confidential computing**: AMD SEV, Intel TDX - VMs encrypted even from the hypervisor.

### Common Mistakes to Avoid

1. **Excessive over-commit**: Allocating more vCPUs than pCPUs degrades performance.
2. **Ignoring NUMA in VMs**: Large VMs must respect NUMA topology.
3. **Containers for security isolation**: Containers do NOT offer the same isolation as VMs.

### Open Questions Remaining

- Will unikernels replace containers for specialised microservices?
- How will isolation evolve for AI workloads on shared accelerators?

## Looking Ahead

**Supplementary Courses Available:**

- **C15supp: Network Connectivity** — Socket API, client-server model, TCP/UDP
- **C16supp: Advanced Containerisation** — Namespaces, cgroups v2, Docker internals
- **C17supp: eBPF and Kernel Programming** — Modern observability, bpftrace, BCC
- **C18supp: NPU Integration** — Specialised AI/ML processors in modern OSes

These modules are optional and aimed at students who wish to delve deeper into specific topics.

## Visual Summary

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    WEEK 14: RECAP - VIRTUALISATION                           │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  VIRTUALISATION                                                              │
│  ├── Hypervisor Type 1 (bare-metal): ESXi, Hyper-V, KVM                     │
│  ├── Hypervisor Type 2 (hosted): VirtualBox, VMware Workstation             │
│  ├── Full virtualisation: Unmodified Guest OS                               │
│  └── Paravirtualisation: Guest OS cooperates (hypercalls)                   │
│                                                                              │
│  CONTAINERISATION                                                            │
│  ├── Shared kernel (vs. VM: separate kernel)                                │
│  ├── Fast boot (<1s vs. minutes)                                            │
│  ├── Small size (MB vs. GB)                                                 │
│  └── Isolation: namespaces + cgroups                                        │
│                                                                              │
│  LINUX NAMESPACES (isolation)                                                │
│  ├── PID: Isolated processes                                                │
│  ├── NET: Isolated network                                                  │
│  ├── MNT: Isolated filesystem                                               │
│  ├── UTS: Isolated hostname                                                 │
│  ├── IPC: Isolated IPC                                                      │
│  └── USER: UID/GID mapping                                                  │
│                                                                              │
│  CGROUPS (resource limits)                                                   │
│  ├── cpu: CPU time                                                          │
│  ├── memory: RAM                                                            │
│  ├── blkio: Disk I/O                                                        │
│  └── pids: Number of processes                                              │
│                                                                              │
│  DOCKER                                                                      │
│  ├── Image: Read-only template                                              │
│  ├── Container: Running instance                                            │
│  ├── Volume: Persistent data                                                │
│  └── Network: Communication between containers                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## Good Luck on the Exam!

This knowledge is fundamental for any IT career - from software development to system administration, from cloud computing to security. A deep understanding of operating systems will make you a better professional, regardless of the specific field in which you will work.


---

## Self-Assessment

### Verification Questions

1. **[REMEMBER]** What is a hypervisor? What is the difference between Type 1 (bare-metal) and Type 2 (hosted)?
2. **[UNDERSTAND]** Explain the fundamental difference between a virtual machine and a container. What do containers share with the host?
3. **[ANALYSE]** Analyse when you would choose VMs vs containers. Consider: isolation, overhead, portability, security.

### Mini-Challenge (optional)

Use `systemd-detect-virt` and `/proc/cpuinfo` to determine if you are running in a virtualised environment and what type.

---

*Materials developed by Revolvix for ASE Bucharest - CSIE*  
*Operating Systems | Year I, Semester 2 | 2025-2026*

---

## Scripting in Context (Bash + Python): Virtualisation Detection and cgroup Limits

### Included Files

- Bash: `scripts/virt_detect.sh` — VM/container detection heuristics.
- Python: `scripts/cgroup_limits.py` — Reports (best-effort) CPU/memory limits from cgroup v2.

### Quick Run

```bash
./scripts/virt_detect.sh
./scripts/cgroup_limits.py
```

### Connection to This Week's Concepts

- VM vs container: isolation at different levels; detection is useful for diagnostics and tuning.
- cgroups explain why two identical processes behave differently in container vs native.

### Recommended Practice

- run the scripts first on a test directory (not on critical data);
- save the output to a file and attach it to the report/assignment if required;
- note the kernel version (`uname -r`) and Python version (`python3 --version`) when comparing results.

*Materials developed by Revolvix for ASE Bucharest - CSIE*  
*Operating Systems | Year I, Semester 2 | 2025-2026*
