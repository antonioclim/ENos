# Course Plan — File System Part 2
> Week 12 | by Revolvix

## Objectives
1. Compare allocation methods: contiguous, linked, indexed
2. Explain FAT structure and extents
3. Describe journaling and recovery
4. Analyse VFS and mounting
