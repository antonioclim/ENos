# Discussion Questions — Filesystem P2

1. **FAT vs inode-based**: Trade-offs?
2. **Why are extents more efficient for large files?**
3. **Metadata-only vs full journaling**: When do you use each?
4. **Why do SSDs not require defragmentation?**
