# ENos lecture bundle

Extract the complete archive, then open `index.html`. Retain `05_LECTURES/` and `assets/` together; their repository-relative paths preserve the canonical HTML bytes. The bundle includes all canonical lecture HTML and the pinned assets, upstream licences and build metadata. Vendored support HTML is counted separately from lecture documents.

`LICENSE`, `LICENCE.md` and `LICENCE_SCOPE.json` record the adopted component licensing and retained exceptions. Keep upstream notices with their assets. The licence map covers the complete repository; `MANIFEST.json` identifies the members present in this lecture bundle.

`MANIFEST.json` records every member except itself with its SHA-256, size and role. This is the ENos 6.0.0 lecture bundle. Source integrity and packaging checks do not establish browser rendering, screen-reader or print acceptance. Diagram PDFs and other repository materials are delivered separately in the complete release source.

The original archive filename claimed 50 but held 48 of 51 sources. The corrected filename states the actual canonical count; three course-07 sources are included. No historical compression corruption was inferred from that coverage defect.
