# ENos lecture bundle

Extract the complete archive, then open `index.html`. Retain `05_LECTURES/` and `assets/` together; their repository-relative paths preserve the canonical HTML bytes. The bundle includes all canonical lecture HTML and the pinned assets, upstream licences and build metadata. Vendored support HTML is counted separately from lecture documents.

`MANIFEST.json` records every member except itself with its SHA-256, size and role. This is a source-integrity/packaging check, not a second independent runtime test. The correction candidate is unpublished. Browser rendering, screen-reader and print acceptance were not obtained in the Phase 5 environment. Diagram PDFs and other repository materials are delivered separately in the complete source candidate.

The original archive filename claimed 50 but held 48 of 51 sources. The corrected filename states the actual canonical count; three course-07 sources are included. No historical compression corruption was inferred from that coverage defect.
