# Discussion Questions — NPU Integration

1. **Why are NPUs energy-efficient for AI?**
2. **When do you prefer CPU vs NPU for inference?**
3. **Why must models be "compiled" for NPU?**
4. **Accel subsystem**: Why a new subsystem in Linux?
