# Lesson Plan — Network Connection
> Week 15 (Supplementary) | by Revolvix

## Objectives
1. Explain the socket API and the client-server model
2. Compare TCP vs UDP and when to use each
3. Implement network communication in C/Python
4. Analyse I/O multiplexing (select, poll, epoll)
