# Discussion Questions — Networking

1. **TCP vs UDP**: When do you choose each protocol?
2. **Why does TCP use a 3-way handshake?**
3. **epoll vs select**: Trade-offs for 10K connections?
4. **Non-blocking I/O**: When and why?
