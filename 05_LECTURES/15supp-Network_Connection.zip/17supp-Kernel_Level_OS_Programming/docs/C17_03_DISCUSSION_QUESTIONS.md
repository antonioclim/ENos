# Discussion Questions — Kernel Programming

1. **Why must kernel code be extra careful?**
2. **printk vs printf**: What are the differences and why?
3. **eBPF**: Why is it revolutionary for observability?
4. **Spinlock in interrupt handler**: Why not mutex?
