# Lecture Plan — Advanced Containerisation
> Week 16 (Supplementary) | by Revolvix

## Objectives
1. Explain kernel mechanisms: namespaces and cgroups
2. Build a minimal container "from scratch"
3. Analyse internal Docker architecture
4. Compare containers vs VMs isolation
