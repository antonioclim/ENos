# Discussion Questions — Containerisation

1. **Why is the fact that containers share the kernel both a pro and a con?**
2. **User namespace**: How does it enable rootless containers?
3. **Cgroups v2 vs v1**: What has changed?
4. **Container escape**: What attack vectors exist?
